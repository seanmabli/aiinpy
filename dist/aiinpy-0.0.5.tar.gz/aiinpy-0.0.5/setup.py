from setuptools import setup

setup(name='aiinpy',
      version='0.0.5',
      description='A simple artificial intelligence library',
      license='MIT',
      packages=['aiinpy'],
      install_requires=['numpy']
      )