# aiinpy
An artificial intelligence library?