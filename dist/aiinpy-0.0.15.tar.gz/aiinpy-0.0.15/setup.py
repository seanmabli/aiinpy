from setuptools import setup

setup(name='aiinpy',
      version='0.0.15',
      description='An artificial intelligence library?',
      license='MIT',
      packages=['aiinpy'],
      install_requires=['numpy']
      )