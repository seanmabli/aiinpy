from setuptools import setup

setup(name='aiinpy',
      version='0.0.9',
      description='An artificial intelligence library',
      license='MIT',
      packages=['aiinpy'],
      install_requires=['numpy']
      )