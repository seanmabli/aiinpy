# aiinpy

aiinpy is an open source artificial intelligence package for the python programming language. aiinpy can be used to build neural networks (nn), convolutional neural networks (cnn), recurrent neural networks (rnn), long term short term memory networks (lstm), and gated recurrent units (gru). these networks can be trained with backpropagation as well as neuroevolution.

install aiinpy through pypi: **pip install aiinpy**