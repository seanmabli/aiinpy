import numpy as np

class gelu:
    pass
