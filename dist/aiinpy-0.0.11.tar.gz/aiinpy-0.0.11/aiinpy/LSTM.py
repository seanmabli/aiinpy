import numpy as np
from .ActivationFunctions import Sigmoid, Tanh, ReLU, LeakyReLU, StableSoftMax

class LSTM:
  def __init__(self):
    print('Not Started')